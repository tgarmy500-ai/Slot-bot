"""
╔══════════════════════════════════════════╗
║        SMUGGLER SLOTS — Discord Bot      ║
║   Professional Slot Management System   ║
╚══════════════════════════════════════════╝

SETUP:
  1. Copy .env.example → .env
  2. Fill in DISCORD_TOKEN and GUILD_ID
  3. pip3 install -r requirements.txt
  4. python3 bot.py

TOKEN: Get from https://discord.com/developers/applications
       Bot → Reset Token → Copy it
"""

import discord
from discord.ext import commands, tasks
from discord import app_commands
import sqlite3
import os
import logging
from datetime import datetime, timedelta
from typing import Optional

# ══════════════════════════════════════════════
#  CONFIG — Edit these or use .env file
# ══════════════════════════════════════════════

# ── REQUIRED ──────────────────────────────────
# Get your token from: https://discord.com/developers/applications
# Go to your app → Bot → Reset Token → copy it
TOKEN = os.getenv("DISCORD_TOKEN", "MTUxODU2NTQ3MzU0Nzk4MDgwMQ.GN06Qd.1VkWO68bKwbLCC0nbqY-xkSwe7MsKxdOp8NwOQ")

# Right-click your server icon → Copy Server ID
# (Enable Developer Mode: User Settings → Advanced → Developer Mode)
GUILD_ID = int(os.getenv("GUILD_ID", "1495786428490059866"))

# ── OPTIONAL ──────────────────────────────────
# Role name that can use /slot commands (besides Admins)
MOD_ROLE_NAME = os.getenv("MOD_ROLE", "Slot Manager")

# Max @here pings before slot is auto-held
MAX_HERE_PINGS = int(os.getenv("MAX_HERE_PINGS", "2"))

# Max @everyone pings (set 0 to disable tracking)
MAX_EVERYONE_PINGS = int(os.getenv("MAX_EVERYONE_PINGS", "0"))

# Message appended after ping counter (shown in channel)
# Example output: • 2/2 @here | USE MM TO BE SAFE
PING_SUFFIX = os.getenv("PING_SUFFIX", "USE MM TO BE SAFE")

# Bot avatar thumbnail URL shown on slot info cards
# Leave blank to use the bot's own avatar
BOT_THUMBNAIL = os.getenv("BOT_THUMBNAIL", "")

# Accent colour for slot info embed (hex, e.g. "b000ff" for purple)
EMBED_COLOR = int(os.getenv("EMBED_COLOR", "b000ff"), 16)

# ══════════════════════════════════════════════
#  LOGGING
# ══════════════════════════════════════════════
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler("smuggler_slots.log"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger("SmugglerSlots")

# ══════════════════════════════════════════════
#  DATABASE
# ══════════════════════════════════════════════
DB_PATH = "slots.db"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS slots (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id         TEXT NOT NULL,
            user_id          TEXT NOT NULL,
            category         TEXT,
            status           TEXT NOT NULL DEFAULT 'active',
            duration_hours   INTEGER,
            created_at       TEXT NOT NULL,
            expires_at       TEXT,
            held_at          TEXT,
            here_pings       INTEGER NOT NULL DEFAULT 0,
            everyone_pings   INTEGER NOT NULL DEFAULT 0,
            notes            TEXT
        );

        CREATE TABLE IF NOT EXISTS slot_history (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            slot_id     INTEGER NOT NULL,
            action      TEXT NOT NULL,
            actor_id    TEXT NOT NULL,
            reason      TEXT,
            timestamp   TEXT NOT NULL
        );
    """)
    conn.commit()
    conn.close()
    log.info("Database initialised.")

# ══════════════════════════════════════════════
#  HELPERS
# ══════════════════════════════════════════════
def now_str():
    return datetime.utcnow().isoformat()

def fmt_relative(iso: str | None) -> str:
    """Return a human-readable relative time string."""
    if not iso:
        return "Never"
    try:
        dt = datetime.fromisoformat(iso)
        now = datetime.utcnow()
        delta = dt - now
        past = delta.total_seconds() < 0
        secs = abs(delta.total_seconds())

        if secs < 60:
            s = f"{int(secs)} seconds"
        elif secs < 3600:
            s = f"{int(secs // 60)} minutes"
        elif secs < 86400:
            s = f"{int(secs // 3600)} hours"
        elif secs < 86400 * 30:
            s = f"{int(secs // 86400)} days"
        elif secs < 86400 * 365:
            months = int(secs // (86400 * 30))
            s = f"{months} month{'s' if months > 1 else ''}"
        else:
            years = int(secs // (86400 * 365))
            s = f"{years} year{'s' if years > 1 else ''}"

        return f"{s} ago" if past else f"in {s}"
    except Exception:
        return iso

def has_mod_role():
    async def predicate(interaction: discord.Interaction) -> bool:
        if interaction.user.guild_permissions.administrator:
            return True
        return any(r.name == MOD_ROLE_NAME for r in interaction.user.roles)
    return app_commands.check(predicate)

def status_emoji(status: str) -> str:
    return {"active": "🟢", "held": "🔴", "revoked": "⛔"}.get(status, "⚪")

async def log_action(slot_id: int, action: str, actor_id: int, reason: str = ""):
    conn = get_db()
    conn.execute(
        "INSERT INTO slot_history (slot_id, action, actor_id, reason, timestamp) VALUES (?,?,?,?,?)",
        (slot_id, action, str(actor_id), reason, now_str())
    )
    conn.commit()
    conn.close()

def build_slot_info_embed(slot, user: discord.Member, bot_user: discord.User) -> discord.Embed:
    """
    Build the Slot Info embed styled like the reference image:
    ┌─────────────────────────────────────┐
    │ Slot Info               [thumbnail] │
    │                                     │
    │ User                                │
    │ @username                           │
    │                                     │
    │ Duration                            │
    │ 99                                  │
    │                                     │
    │ Category                            │
    │ 001                                 │
    │                                     │
    │ Created                             │
    │ 5 days ago                          │
    │                                     │
    │ Expiry                              │
    │ in 3 months                         │
    │                                     │
    │ Ping Allowed                        │
    │ @everyone : 0                       │
    │ @here : 2                           │
    └─────────────────────────────────────┘
    """
    embed = discord.Embed(title="Slot Info", color=EMBED_COLOR)

    # Thumbnail (top-right corner)
    thumb = BOT_THUMBNAIL or bot_user.display_avatar.url
    embed.set_thumbnail(url=thumb)

    embed.add_field(name="User", value=user.mention, inline=False)

    duration_val = str(slot["duration_hours"]) if slot["duration_hours"] else "∞"
    embed.add_field(name="Duration", value=duration_val, inline=False)

    category_val = slot["category"] if slot["category"] else "—"
    embed.add_field(name="Category", value=category_val, inline=False)

    embed.add_field(name="Created", value=fmt_relative(slot["created_at"]), inline=False)
    embed.add_field(name="Expiry", value=fmt_relative(slot["expires_at"]), inline=False)

    ping_block = (
        f"```\n"
        f"@everyone : {slot['everyone_pings']}\n"
        f"@here : {slot['here_pings']}/{MAX_HERE_PINGS}\n"
        f"```"
    )
    embed.add_field(name="Ping Allowed", value=ping_block, inline=False)

    embed.set_footer(text="Smuggler Slots • Professional Slot Management")
    return embed

# ══════════════════════════════════════════════
#  BOT
# ══════════════════════════════════════════════
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.guilds = True

bot = commands.Bot(command_prefix="!", intents=intents)
tree = bot.tree

# ══════════════════════════════════════════════
#  SLASH COMMAND GROUP: /slot
# ══════════════════════════════════════════════
slot_group = app_commands.Group(
    name="slot",
    description="Smuggler Slots management commands"
)

# ── /slot create ──────────────────────────────
@slot_group.command(name="create", description="Create a slot for a user")
@app_commands.describe(
    user="The user to give a slot",
    duration="Duration in hours (e.g. 720 = 30 days). Leave blank for no expiry.",
    category="Slot category label (e.g. 001, VIP, Standard)"
)
@has_mod_role()
async def slot_create(
    interaction: discord.Interaction,
    user: discord.Member,
    duration: Optional[int] = None,
    category: Optional[str] = None
):
    await interaction.response.defer(ephemeral=False)

    conn = get_db()
    existing = conn.execute(
        "SELECT * FROM slots WHERE guild_id=? AND user_id=? AND status IN ('active','held')",
        (str(interaction.guild_id), str(user.id))
    ).fetchone()
    if existing:
        conn.close()
        await interaction.followup.send(embed=discord.Embed(
            title="⚠️ Slot Already Exists",
            description=f"{user.mention} already has an **{existing['status']}** slot.",
            color=discord.Color.yellow()
        ))
        return

    expires_at = None
    if duration:
        expires_at = (datetime.utcnow() + timedelta(hours=duration)).isoformat()

    cur = conn.execute(
        "INSERT INTO slots (guild_id, user_id, category, status, duration_hours, created_at, expires_at) VALUES (?,?,?,?,?,?,?)",
        (str(interaction.guild_id), str(user.id), category, "active", duration, now_str(), expires_at)
    )
    slot_id = cur.lastrowid
    conn.commit()
    slot = conn.execute("SELECT * FROM slots WHERE id=?", (slot_id,)).fetchone()
    conn.close()

    await log_action(slot_id, "create", interaction.user.id)

    embed = build_slot_info_embed(slot, user, bot.user)
    embed.title = "✅ Slot Created"
    embed.color = discord.Color.green()

    await interaction.followup.send(content=user.mention, embed=embed)
    log.info(f"Slot #{slot_id} created for {user} by {interaction.user}")


# ── /slot revoke ──────────────────────────────
@slot_group.command(name="revoke", description="Permanently remove a user's slot")
@app_commands.describe(user="The user whose slot to revoke", reason="Reason for revocation")
@has_mod_role()
async def slot_revoke(interaction: discord.Interaction, user: discord.Member, reason: Optional[str] = "No reason provided"):
    await interaction.response.defer(ephemeral=False)

    conn = get_db()
    slot = conn.execute(
        "SELECT * FROM slots WHERE guild_id=? AND user_id=? AND status IN ('active','held')",
        (str(interaction.guild_id), str(user.id))
    ).fetchone()
    if not slot:
        conn.close()
        await interaction.followup.send(embed=discord.Embed(
            title="❌ No Active Slot",
            description=f"{user.mention} does not have an active or held slot.",
            color=discord.Color.red()
        ))
        return

    conn.execute("UPDATE slots SET status='revoked' WHERE id=?", (slot["id"],))
    conn.commit()
    conn.close()
    await log_action(slot["id"], "revoke", interaction.user.id, reason)

    embed = discord.Embed(
        title="⛔ Slot Revoked",
        description=f"The slot for {user.mention} has been **permanently removed**.",
        color=discord.Color.red()
    )
    embed.add_field(name="Reason", value=reason, inline=False)
    embed.set_footer(text="Smuggler Slots • Professional Slot Management")
    embed.timestamp = datetime.utcnow()
    await interaction.followup.send(embed=embed)

    try:
        dm = discord.Embed(
            title="⛔ Your Slot Has Been Revoked",
            description=f"Your slot in **{interaction.guild.name}** has been permanently removed.",
            color=discord.Color.red()
        )
        dm.add_field(name="Reason", value=reason, inline=False)
        await user.send(embed=dm)
    except discord.Forbidden:
        pass

    log.info(f"Slot #{slot['id']} revoked for {user} — {reason}")


# ── /slot hold ────────────────────────────────
@slot_group.command(name="hold", description="Put a user's slot on hold")
@app_commands.describe(user="The user whose slot to hold", reason="Reason for holding")
@has_mod_role()
async def slot_hold(interaction: discord.Interaction, user: discord.Member, reason: Optional[str] = "No reason provided"):
    await interaction.response.defer(ephemeral=False)

    conn = get_db()
    slot = conn.execute(
        "SELECT * FROM slots WHERE guild_id=? AND user_id=? AND status='active'",
        (str(interaction.guild_id), str(user.id))
    ).fetchone()
    if not slot:
        conn.close()
        await interaction.followup.send(embed=discord.Embed(
            title="❌ No Active Slot",
            description=f"{user.mention} does not have an active slot to hold.",
            color=discord.Color.red()
        ))
        return

    conn.execute("UPDATE slots SET status='held', held_at=? WHERE id=?", (now_str(), slot["id"]))
    conn.commit()
    conn.close()
    await log_action(slot["id"], "hold", interaction.user.id, reason)

    embed = discord.Embed(
        title="🔴 Slot On Hold",
        description=f"{user.mention}'s slot has been placed on **hold**.",
        color=discord.Color.orange()
    )
    embed.add_field(name="Reason", value=reason, inline=False)
    embed.set_footer(text="Smuggler Slots • Use /slot release to restore")
    embed.timestamp = datetime.utcnow()
    await interaction.followup.send(embed=embed)

    try:
        dm = discord.Embed(
            title="🔴 Your Slot Is On Hold",
            description=f"Your slot in **{interaction.guild.name}** has been placed on hold.",
            color=discord.Color.orange()
        )
        dm.add_field(name="Reason", value=reason, inline=False)
        dm.add_field(name="Action Required", value="Contact a staff member to have your slot released.", inline=False)
        await user.send(embed=dm)
    except discord.Forbidden:
        pass

    log.info(f"Slot #{slot['id']} held for {user} — {reason}")


# ── /slot release ─────────────────────────────
@slot_group.command(name="release", description="Release a user's held slot")
@app_commands.describe(user="The user whose slot to release")
@has_mod_role()
async def slot_release(interaction: discord.Interaction, user: discord.Member):
    await interaction.response.defer(ephemeral=False)

    conn = get_db()
    slot = conn.execute(
        "SELECT * FROM slots WHERE guild_id=? AND user_id=? AND status='held'",
        (str(interaction.guild_id), str(user.id))
    ).fetchone()
    if not slot:
        conn.close()
        await interaction.followup.send(embed=discord.Embed(
            title="❌ No Held Slot",
            description=f"{user.mention} does not have a held slot.",
            color=discord.Color.red()
        ))
        return

    conn.execute(
        "UPDATE slots SET status='active', held_at=NULL, here_pings=0, everyone_pings=0 WHERE id=?",
        (slot["id"],)
    )
    conn.commit()
    updated = conn.execute("SELECT * FROM slots WHERE id=?", (slot["id"],)).fetchone()
    conn.close()
    await log_action(slot["id"], "release", interaction.user.id)

    embed = discord.Embed(
        title="🟢 Slot Released",
        description=f"{user.mention}'s slot is now **active**. Ping counter reset.",
        color=discord.Color.green()
    )
    embed.set_footer(text="Smuggler Slots • Professional Slot Management")
    embed.timestamp = datetime.utcnow()
    await interaction.followup.send(content=user.mention, embed=embed)

    try:
        dm = discord.Embed(
            title="🟢 Your Slot Has Been Released",
            description=f"Your slot in **{interaction.guild.name}** is active again. Ping counter has been reset.",
            color=discord.Color.green()
        )
        await user.send(embed=dm)
    except discord.Forbidden:
        pass

    log.info(f"Slot #{slot['id']} released for {user}")


# ── /slot warn ────────────────────────────────
@slot_group.command(name="warn", description="Send a DM warning to a slot holder")
@app_commands.describe(user="The user to warn", reason="The warning reason")
@has_mod_role()
async def slot_warn(interaction: discord.Interaction, user: discord.Member, reason: str):
    await interaction.response.defer(ephemeral=False)

    conn = get_db()
    slot = conn.execute(
        "SELECT * FROM slots WHERE guild_id=? AND user_id=? AND status IN ('active','held')",
        (str(interaction.guild_id), str(user.id))
    ).fetchone()
    conn.close()

    if not slot:
        await interaction.followup.send(embed=discord.Embed(
            title="❌ No Slot Found",
            description=f"{user.mention} does not have an active or held slot.",
            color=discord.Color.red()
        ))
        return

    await log_action(slot["id"], "warn", interaction.user.id, reason)

    dm_sent = True
    try:
        dm = discord.Embed(
            title="⚠️ Official Warning — Smuggler Slots",
            description=f"You have received a warning for your slot in **{interaction.guild.name}**.",
            color=discord.Color.yellow()
        )
        dm.add_field(name="Reason", value=reason, inline=False)
        dm.add_field(name="Notice", value="Further violations may result in your slot being held or permanently revoked.", inline=False)
        dm.set_footer(text="Smuggler Slots • Professional Slot Management")
        dm.timestamp = datetime.utcnow()
        await user.send(embed=dm)
    except discord.Forbidden:
        dm_sent = False

    embed = discord.Embed(title="⚠️ Warning Issued", color=discord.Color.yellow())
    embed.add_field(name="User", value=user.mention, inline=True)
    embed.add_field(name="DM Delivered", value="✅ Yes" if dm_sent else "❌ DMs Closed", inline=True)
    embed.add_field(name="Reason", value=reason, inline=False)
    embed.set_footer(text="Smuggler Slots • Professional Slot Management")
    embed.timestamp = datetime.utcnow()
    await interaction.followup.send(embed=embed)

    log.info(f"Warning sent to {user} — {reason}")


# ── /slot transfer ────────────────────────────
@slot_group.command(name="transfer", description="Move a slot from one user to another")
@app_commands.describe(
    from_user="The current slot holder",
    to_user="The user to receive the slot"
)
@has_mod_role()
async def slot_transfer(interaction: discord.Interaction, from_user: discord.Member, to_user: discord.Member):
    await interaction.response.defer(ephemeral=False)

    conn = get_db()
    slot = conn.execute(
        "SELECT * FROM slots WHERE guild_id=? AND user_id=? AND status IN ('active','held')",
        (str(interaction.guild_id), str(from_user.id))
    ).fetchone()
    if not slot:
        conn.close()
        await interaction.followup.send(embed=discord.Embed(
            title="❌ No Slot Found",
            description=f"{from_user.mention} does not have an active or held slot.",
            color=discord.Color.red()
        ))
        return

    existing = conn.execute(
        "SELECT id FROM slots WHERE guild_id=? AND user_id=? AND status IN ('active','held')",
        (str(interaction.guild_id), str(to_user.id))
    ).fetchone()
    if existing:
        conn.close()
        await interaction.followup.send(embed=discord.Embed(
            title="⚠️ Target Already Has a Slot",
            description=f"{to_user.mention} already holds a slot. Revoke it first.",
            color=discord.Color.yellow()
        ))
        return

    conn.execute(
        "UPDATE slots SET user_id=?, status='active', here_pings=0, everyone_pings=0, held_at=NULL WHERE id=?",
        (str(to_user.id), slot["id"])
    )
    conn.commit()
    conn.close()
    await log_action(slot["id"], "transfer", interaction.user.id, f"from:{from_user.id} to:{to_user.id}")

    embed = discord.Embed(title="🔄 Slot Transferred", color=discord.Color.blurple())
    embed.add_field(name="From", value=from_user.mention, inline=True)
    embed.add_field(name="To", value=to_user.mention, inline=True)
    embed.set_footer(text="Smuggler Slots • Professional Slot Management")
    embed.timestamp = datetime.utcnow()
    await interaction.followup.send(embed=embed)

    log.info(f"Slot #{slot['id']} transferred from {from_user} to {to_user}")


# ── /slot timer ───────────────────────────────
@slot_group.command(name="timer", description="Set or clear the expiry timer on a slot")
@app_commands.describe(
    user="The slot holder",
    hours="Hours from now (leave blank to clear the timer)"
)
@has_mod_role()
async def slot_timer(interaction: discord.Interaction, user: discord.Member, hours: Optional[int] = None):
    await interaction.response.defer(ephemeral=False)

    conn = get_db()
    slot = conn.execute(
        "SELECT * FROM slots WHERE guild_id=? AND user_id=? AND status IN ('active','held')",
        (str(interaction.guild_id), str(user.id))
    ).fetchone()
    if not slot:
        conn.close()
        await interaction.followup.send(embed=discord.Embed(
            title="❌ No Slot Found",
            description=f"{user.mention} does not have an active or held slot.",
            color=discord.Color.red()
        ))
        return

    if hours is None:
        conn.execute("UPDATE slots SET expires_at=NULL, duration_hours=NULL WHERE id=?", (slot["id"],))
        result_text = "Timer **cleared** — slot has no expiry."
    else:
        expires_at = (datetime.utcnow() + timedelta(hours=hours)).isoformat()
        conn.execute("UPDATE slots SET expires_at=?, duration_hours=? WHERE id=?", (expires_at, hours, slot["id"]))
        result_text = f"Expires **{fmt_relative(expires_at)}**."

    conn.commit()
    conn.close()
    await log_action(slot["id"], "timer_set", interaction.user.id, f"hours={hours}")

    embed = discord.Embed(title="⏱️ Timer Updated", description=result_text, color=discord.Color.blue())
    embed.add_field(name="User", value=user.mention, inline=True)
    embed.set_footer(text="Smuggler Slots • Professional Slot Management")
    embed.timestamp = datetime.utcnow()
    await interaction.followup.send(embed=embed)


# ── /slot extend ──────────────────────────────
@slot_group.command(name="extend", description="Add hours to a slot's existing timer")
@app_commands.describe(user="The slot holder", hours="Hours to add")
@has_mod_role()
async def slot_extend(interaction: discord.Interaction, user: discord.Member, hours: int):
    await interaction.response.defer(ephemeral=False)

    conn = get_db()
    slot = conn.execute(
        "SELECT * FROM slots WHERE guild_id=? AND user_id=? AND status IN ('active','held')",
        (str(interaction.guild_id), str(user.id))
    ).fetchone()
    if not slot:
        conn.close()
        await interaction.followup.send(embed=discord.Embed(
            title="❌ No Slot Found",
            description=f"{user.mention} does not have an active or held slot.",
            color=discord.Color.red()
        ))
        return

    if slot["expires_at"]:
        base = datetime.fromisoformat(slot["expires_at"])
        if base < datetime.utcnow():
            base = datetime.utcnow()
    else:
        base = datetime.utcnow()

    new_expires = (base + timedelta(hours=hours)).isoformat()
    new_duration = (slot["duration_hours"] or 0) + hours
    conn.execute("UPDATE slots SET expires_at=?, duration_hours=? WHERE id=?", (new_expires, new_duration, slot["id"]))
    conn.commit()
    conn.close()
    await log_action(slot["id"], "extend", interaction.user.id, f"+{hours}h")

    embed = discord.Embed(title="⏩ Slot Extended", color=discord.Color.blue())
    embed.add_field(name="User", value=user.mention, inline=True)
    embed.add_field(name="Added", value=f"+{hours} hour(s)", inline=True)
    embed.add_field(name="New Expiry", value=fmt_relative(new_expires), inline=False)
    embed.set_footer(text="Smuggler Slots • Professional Slot Management")
    embed.timestamp = datetime.utcnow()
    await interaction.followup.send(embed=embed)


# ── /slot info ────────────────────────────────
@slot_group.command(name="info", description="View full slot details for a user")
@app_commands.describe(user="The slot holder to look up")
@has_mod_role()
async def slot_info(interaction: discord.Interaction, user: discord.Member):
    await interaction.response.defer(ephemeral=True)

    conn = get_db()
    slot = conn.execute(
        "SELECT * FROM slots WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT 1",
        (str(interaction.guild_id), str(user.id))
    ).fetchone()

    if not slot:
        conn.close()
        await interaction.followup.send(embed=discord.Embed(
            title="❌ No Slot Found",
            description=f"{user.mention} has never had a slot.",
            color=discord.Color.red()
        ), ephemeral=True)
        return

    history = conn.execute(
        "SELECT * FROM slot_history WHERE slot_id=? ORDER BY timestamp DESC LIMIT 5",
        (slot["id"],)
    ).fetchall()
    conn.close()

    embed = build_slot_info_embed(slot, user, bot.user)

    if history:
        lines = []
        for h in history:
            try:
                actor = interaction.guild.get_member(int(h["actor_id"]))
                actor_name = actor.display_name if actor else f"<@{h['actor_id']}>"
            except Exception:
                actor_name = f"<@{h['actor_id']}>"
            r = f" — {h['reason']}" if h["reason"] else ""
            lines.append(f"`{h['action'].upper()}` by {actor_name}{r}")
        embed.add_field(name="Recent Activity", value="\n".join(lines), inline=False)

    if slot["notes"]:
        embed.add_field(name="📝 Staff Note", value=slot["notes"], inline=False)

    await interaction.followup.send(embed=embed, ephemeral=True)


# ── /slot list ────────────────────────────────
@slot_group.command(name="list", description="View all active and held slots")
@has_mod_role()
async def slot_list(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)

    conn = get_db()
    slots = conn.execute(
        "SELECT * FROM slots WHERE guild_id=? AND status IN ('active','held') ORDER BY status, created_at",
        (str(interaction.guild_id),)
    ).fetchall()
    conn.close()

    if not slots:
        await interaction.followup.send(embed=discord.Embed(
            title="📋 No Active Slots",
            description="There are no active or held slots right now.",
            color=EMBED_COLOR
        ), ephemeral=True)
        return

    active = [s for s in slots if s["status"] == "active"]
    held   = [s for s in slots if s["status"] == "held"]

    embed = discord.Embed(
        title="📋 Slot List",
        description=f"**{len(slots)}** total  |  🟢 {len(active)} active  |  🔴 {len(held)} held",
        color=EMBED_COLOR
    )

    def build_lines(slot_list):
        lines = []
        for s in slot_list:
            member = interaction.guild.get_member(int(s["user_id"]))
            name = member.mention if member else f"<@{s['user_id']}>"
            cat = f"`{s['category']}`" if s["category"] else ""
            ping_bar = f"[{'█' * s['here_pings']}{'░' * max(0, MAX_HERE_PINGS - s['here_pings'])}]"
            lines.append(f"{status_emoji(s['status'])} {name} {cat} {ping_bar} @here")
        return "\n".join(lines) if lines else "None"

    if active:
        embed.add_field(name="🟢 Active", value=build_lines(active), inline=False)
    if held:
        embed.add_field(name="🔴 Held", value=build_lines(held), inline=False)

    embed.set_footer(text="Smuggler Slots • Professional Slot Management")
    embed.timestamp = datetime.utcnow()
    await interaction.followup.send(embed=embed, ephemeral=True)


# ── /slot note ────────────────────────────────
@slot_group.command(name="note", description="Add an internal staff note to a slot")
@app_commands.describe(user="The slot holder", text="The note text")
@has_mod_role()
async def slot_note(interaction: discord.Interaction, user: discord.Member, text: str):
    await interaction.response.defer(ephemeral=True)

    conn = get_db()
    slot = conn.execute(
        "SELECT * FROM slots WHERE guild_id=? AND user_id=? AND status IN ('active','held')",
        (str(interaction.guild_id), str(user.id))
    ).fetchone()
    if not slot:
        conn.close()
        await interaction.followup.send("❌ No active/held slot found for that user.", ephemeral=True)
        return

    conn.execute("UPDATE slots SET notes=? WHERE id=?", (text, slot["id"]))
    conn.commit()
    conn.close()
    await log_action(slot["id"], "note", interaction.user.id, text)

    await interaction.followup.send(embed=discord.Embed(
        title="📝 Note Saved",
        description=f"Note added to {user.mention}'s slot. Visible in `/slot info`.",
        color=discord.Color.blue()
    ), ephemeral=True)

tree.add_command(slot_group)

# ══════════════════════════════════════════════
#  PING MONITORING  — @here and @everyone
# ══════════════════════════════════════════════
@bot.event
async def on_message(message: discord.Message):
    if message.author.bot or not message.guild:
        return

    has_here     = "@here" in message.content
    has_everyone = "@everyone" in message.content

    if has_here or has_everyone:
        conn = get_db()
        slot = conn.execute(
            "SELECT * FROM slots WHERE guild_id=? AND user_id=? AND status='active'",
            (str(message.guild.id), str(message.author.id))
        ).fetchone()

        if slot:
            new_here     = slot["here_pings"] + (1 if has_here else 0)
            new_everyone = slot["everyone_pings"] + (1 if has_everyone else 0)

            conn.execute(
                "UPDATE slots SET here_pings=?, everyone_pings=? WHERE id=?",
                (new_here, new_everyone, slot["id"])
            )
            conn.commit()
            conn.close()

            # ── @here logic ────────────────────────────
            if has_here:
                remaining = MAX_HERE_PINGS - new_here

                if new_here > MAX_HERE_PINGS:
                    # Auto-hold
                    conn2 = get_db()
                    conn2.execute(
                        "UPDATE slots SET status='held', held_at=? WHERE id=?",
                        (now_str(), slot["id"])
                    )
                    conn2.commit()
                    conn2.close()
                    await log_action(slot["id"], "auto_hold", bot.user.id,
                                     f"Exceeded @here limit ({new_here}/{MAX_HERE_PINGS})")

                    hold_embed = discord.Embed(
                        title="🔴 Slot Auto-Held — Ping Limit Exceeded",
                        description=(
                            f"{message.author.mention} your slot has been **automatically held** "
                            f"for exceeding the @here ping limit of **{MAX_HERE_PINGS}**.\n\n"
                            "Contact a staff member to release your slot."
                        ),
                        color=discord.Color.red()
                    )
                    hold_embed.set_footer(text="Smuggler Slots • Professional Slot Management")
                    await message.channel.send(embed=hold_embed)

                    try:
                        dm = discord.Embed(
                            title="🔴 Your Slot Has Been Auto-Held",
                            description=f"You exceeded the @here limit in **{message.guild.name}**. Contact staff to release it.",
                            color=discord.Color.red()
                        )
                        await message.author.send(embed=dm)
                    except discord.Forbidden:
                        pass

                    log.info(f"Auto-held slot #{slot['id']} for {message.author} — ping #{new_here}")

                else:
                    # ── Post ping counter message (matches reference image) ──
                    # Format: • 2/2 @here | USE MM TO BE SAFE
                    counter_msg = f"• {new_here}/{MAX_HERE_PINGS} @here | {PING_SUFFIX}"
                    await message.channel.send(counter_msg)

                    # Additional warning at final ping
                    if remaining == 0:
                        warn_embed = discord.Embed(
                            title="⚠️ Final @here Ping Used",
                            description=(
                                f"{message.author.mention} you have used **all {MAX_HERE_PINGS}** @here pings.\n"
                                "Any further @here pings will **automatically hold** your slot."
                            ),
                            color=discord.Color.yellow()
                        )
                        warn_embed.set_footer(text="Smuggler Slots • Professional Slot Management")
                        await message.channel.send(embed=warn_embed)

        else:
            conn.close()

    await bot.process_commands(message)


# ══════════════════════════════════════════════
#  TIMER EXPIRY — checks every 60 seconds
# ══════════════════════════════════════════════
@tasks.loop(seconds=60)
async def check_timers():
    conn = get_db()
    expired = conn.execute(
        "SELECT * FROM slots WHERE status='active' AND expires_at IS NOT NULL AND expires_at <= ?",
        (now_str(),)
    ).fetchall()
    conn.close()

    for slot in expired:
        conn2 = get_db()
        conn2.execute("UPDATE slots SET status='revoked' WHERE id=?", (slot["id"],))
        conn2.commit()
        conn2.close()
        await log_action(slot["id"], "timer_expired", bot.user.id, "Slot timer expired")

        for guild in bot.guilds:
            if str(guild.id) == slot["guild_id"]:
                try:
                    member = guild.get_member(int(slot["user_id"])) or \
                             await guild.fetch_member(int(slot["user_id"]))
                    dm = discord.Embed(
                        title="⏰ Slot Expired",
                        description=f"Your slot in **{guild.name}** has expired and been removed.",
                        color=discord.Color.dark_gray()
                    )
                    await member.send(embed=dm)
                except Exception:
                    pass

        log.info(f"Slot #{slot['id']} expired (user {slot['user_id']})")


# ══════════════════════════════════════════════
#  BOT EVENTS
# ══════════════════════════════════════════════
@bot.event
async def on_ready():
    init_db()
    check_timers.start()

    if GUILD_ID:
        guild = discord.Object(id=GUILD_ID)
        tree.copy_global_to(guild=guild)
        await tree.sync(guild=guild)
        log.info(f"Commands synced instantly to guild {GUILD_ID}")
    else:
        await tree.sync()
        log.info("Commands synced globally (may take up to 1 hour to appear)")

    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name="🔫 Smuggler Slots"
        )
    )

    log.info(
        f"\n"
        f"╔══════════════════════════════════════╗\n"
        f"║     Smuggler Slots — Online ✅        ║\n"
        f"║  Bot: {bot.user} ({bot.user.id})\n"
        f"║  Guild ID: {GUILD_ID}\n"
        f"║  @here limit: {MAX_HERE_PINGS}\n"
        f"╚══════════════════════════════════════╝"
    )


@bot.event
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.CheckFailure):
        await interaction.response.send_message(
            embed=discord.Embed(
                title="🚫 Permission Denied",
                description=f"You need the **{MOD_ROLE_NAME}** role or Administrator to use this command.",
                color=discord.Color.red()
            ),
            ephemeral=True
        )
    else:
        log.error(f"Command error: {error}", exc_info=True)
        try:
            msg = discord.Embed(
                title="❌ Error",
                description=str(error),
                color=discord.Color.red()
            )
            if not interaction.response.is_done():
                await interaction.response.send_message(embed=msg, ephemeral=True)
            else:
                await interaction.followup.send(embed=msg, ephemeral=True)
        except Exception:
            pass


# ══════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════
if __name__ == "__main__":
    if TOKEN in ("PASTE_YOUR_BOT_TOKEN_HERE", ""):
        print("\n" + "═" * 50)
        print("  ❌  ERROR: No bot token set!")
        print("  Open .env and paste your token:")
        print("  DISCORD_TOKEN=your_token_here")
        print("═" * 50 + "\n")
        exit(1)

    if GUILD_ID == 0:
        print("\n⚠️  WARNING: GUILD_ID not set — commands will sync globally (slow).")
        print("  Set GUILD_ID in .env for instant sync.\n")

    bot.run(TOKEN, log_handler=None)
